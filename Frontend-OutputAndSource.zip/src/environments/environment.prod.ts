export const environment = {
  production: true,
  product: "http://ad3a099ce5ccf11e9b816061ccc00add-2077432565.ap-southeast-1.elb.amazonaws.com",
  order: "http://ordertest.eu-west-1.elasticbeanstalk.com",
  customer: "http://customertest.eu-west-1.elasticbeanstalk.com",
  payment: "http://paymenttest.eu-west-1.elasticbeanstalk.com",
};
